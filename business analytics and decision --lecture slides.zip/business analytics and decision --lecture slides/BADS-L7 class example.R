# If you want to download the file
# Use: http://www.hodgett.co.uk/sleep.csv
# Then set your Working Directory
setwd("C:\\FILE LOCATION\\")

# Import sleep dataset to dataframe sleep
sleep <- read.csv("sleep.csv")

# If you want to import directly, you can use:
sleep <- read.csv("http://www.hodgett.co.uk/sleep.csv")

# Install dplyr package
install.packages("dplyr")
library("dplyr")

# Have a look at sleep - mammal sleep dataset - 62 species. 
sleep

# filter mammal with larger body weight
filter(sleep, BodyWgt >= 150)
filter(sleep, BodyWgt >= 150 & Danger >= 4)

# select without BrainWgt
select(sleep, -BrainWgt)

# arange by weight
arrange(sleep, BodyWgt)

# add column with weight (kg) minus brain weight (in grams)
mutate(sleep, WithoutBrainWeight = BodyWgt - (BrainWgt/1000))


# Install mice
install.packages("mice")
library("mice")

# See where the missing data is - 0 = missing value for a given column var - 1 = indicating a non-missing value
md.pattern(sleep)					

# Test is.na function
sleep[1,]
is.na(sleep[1,3])
is.na(sleep[1,4])

# Number of NA values in Dream column
sum(is.na(sleep$Dream))				

# Number of NULL values in Dream column
sum(is.null(sleep$Dream))	

# Number of NAN values in Dream column
sum(is.nan(sleep$Dream))				

# mean wont work with NA values
mean(sleep$Dream)				

# How to remove NA values
mean(sleep$Dream, na.rm=TRUE)

# Complete cases
complete.cases(sleep)
sum(complete.cases(sleep))
sum(!complete.cases(sleep))

# List incomplete cases
sleep[!complete.cases(sleep),]		

# List complete cases
sleep[complete.cases(sleep),] 				

# Visualise missing data
install.packages("VIM")
library("VIM")

# bar and combinations plot
aggr(sleep, numbers=TRUE)				
aggr(sleep, numbers=TRUE, prop=FALSE)
barMiss(sleep$Dream, selection="all")

# interactive matrixplot
matrixplot(sleep)					

# Simple Imputation
sleep2 <- sleep	
sleep2$Dream[is.na(sleep2$Dream)] <- mean(sleep$Dream, na.rm=TRUE)	
sleep2

# Multiple Imputation - Impute 10 datasets
impute <- mice(sleep, m=10)				
impute
impute$imp
# Show multiple imputed dataset
complete(impute)					 
