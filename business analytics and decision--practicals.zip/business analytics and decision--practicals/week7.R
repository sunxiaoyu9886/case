install.packages("dplyr",dependencies = TRUE)
library('dplyr')

mtcars

filter(mtcars,gear==4)
filter(mtcars,gear==3|gear==4)
filter(mtcars,mpg>21)
select(mtcars,gear,mpg,hp)
select(mtcars,-drat)

arrange(mtcars,gear,mpg)
arrange(mtcars, gear)
arrange(mtcars, desc(mpg))

mutate(mtcars,wt_mpg=wt*mpg)
mutate(mtcars, mpg_mean = mean(mpg), mpg_diff_mean = mpg - mpg_mean)
mean(mtcars$mpg)
mutate(mtcars, mpg_diff_mean = mpg - mean(mpg))

summarise(mtcars,sd(disp))
sd(mtcars$disp)
summarise(mtcars,mean(mpg),median(mpg),max(mpg),min(mpg))

mtcars%>%
group_by(gear) %>%  
summarise(mean(mpg))  

beer <- read.csv("http://www.hodgett.co.uk/brewdog.csv", header=TRUE)
beer
head(beer)
filter(beer,ABV>=8)
filter(beer, Bottle.Size..ml. =="375")
filter(beer, Bottle.Size..ml. == "375ml")

select(beer,Name,Price)
select(beer, Name, Price)
select(beer, Name, Price)

arrange(select(beer,Name, Price),Price)
arrange(select(beer,Name, Price),desc(Price))

arrange(filter(beer, Style == "IPA"), Price)
mutate(beer,ABV_Price=ABV*Price)
summary(beer)



data<-read.csv("http://www.hodgett.co.uk/titanic.csv", header=TRUE)
head(data)
