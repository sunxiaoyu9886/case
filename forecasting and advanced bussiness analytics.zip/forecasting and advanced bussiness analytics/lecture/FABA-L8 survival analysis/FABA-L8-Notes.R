# Install Packages
install.packages("survival")
install.packages("dplyr")

# Add packages to Library
library("survival")
library("dplyr")

# Lecture Simple example
time <- c(3,7,16,25,32,44,49,50,55,72)
type <- c(1,1,1,1,1,1,1,1,1,1)
# Create a survival object
Ex_Surv <- Surv(time, type)
Ex_survfit <- survfit(Ex_Surv ~ 1)
# Create a Kaplan-Meier plot
plot(Ex_survfit, conf.int="none", mark.time=TRUE, xlab="Time (weeks)", ylab="Proportion Survival")

# Lecture Simple example 2
time <- c(3,7,16,25,32,44,49,50,55,72)
type <- c(1,0,1,1,0,1,1,0,1,1)
# Create a survival object
Ex_Surv <- Surv(time, type)
Ex_Surv
Ex_survfit <- survfit(Ex_Surv ~ 1)
# Create a Kaplan-Meier plot
plot(Ex_survfit, conf.int=FALSE, mark.time=TRUE, xlab="Time (weeks)", ylab="Proportion Survival")
plot(Ex_survfit, conf.int=TRUE, mark.time=TRUE, xlab="Time (weeks)", ylab="Proportion Survival")

# Acute Myelogenous Leukemia survival example - data included in the survival package
aml
?aml
data <- data.frame(aml)
AML_Surv <- Surv(aml$time, aml$status)
AML_survfit <- survfit(AML_Surv ~ aml$x)
plot(AML_survfit, conf.int=FALSE, mark.time=TRUE, xlab="Time", ylab="Proportion Survival")
survdiff(AML_Surv~x, data=aml)

