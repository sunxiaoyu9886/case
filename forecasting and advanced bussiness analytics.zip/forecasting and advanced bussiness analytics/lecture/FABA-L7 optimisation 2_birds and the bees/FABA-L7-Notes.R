# Install packages
install.packages("globalOptTests")
install.packages("pso")
library("globalOptTests")	
library("pso")	

# Optimise Camel Back 6-hump Problem
psoptim(fn=goTest, fnName="Camel6", par=c(NA,NA))

# Optimise Camel Back 6-hump Problem using 5,000 iterations
psoptim(fn=goTest, fnName="Camel6", par=c(NA,NA), control = list(maxit = 5000))

# Optimise Ackley�s Problem - 10 dimensional problem
psoptim(fn=goTest, fnName="Ackleys", par=c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA))
