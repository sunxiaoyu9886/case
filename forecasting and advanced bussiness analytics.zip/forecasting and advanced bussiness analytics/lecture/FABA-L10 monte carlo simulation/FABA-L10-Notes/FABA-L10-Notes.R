########## PART ONE ###########

# We can represent our toys as numbers 1-10 and simply place as many of that number into a vector as there are as many chances in 30 of getting that toy
toys <- c(1,1,1,1,1,2,2,3,3,4,4,5,5,5,5,6,6,7,7,7,7,8,8,8,8,8,9,9,10,10)

# Now we can create a function which uses a while loop to continually loop until all 10 of the toys have been randomly chosen
collectall <- function(){
  					owned <- c()
  					while(length(unique(owned)) < 10) { owned <- c(owned, sample(toys, 1, replace=T)) }
					length(owned) 
				}

# We can then run this function 10,000 times and then study the results
results <- replicate(10000, collectall())

# We can return the mean of the results with		
mean(results)

# We can also create a density plot of the results with
plot(density(results))

# Now wasn't that easy?

########## PART TWO ###########

# Number of Simulations
n <- 100000

### Normal Distribution
x <- rnorm(n, mean=0, sd=1)
# Plot of all the random points
plot(x, main='random draws from a normal distribution') 
# A histogram of the samples
hist(x, probability=TRUE)                    
# Overlay distribution
curve(dnorm(x, mean=0, sd=1), add=TRUE) 
                 
### Beta Distribution
?rbeta
x<-rbeta(n, 7, 2)
plot(x, main='random draws from a beta distribution')
hist(x, probability=TRUE)
curve(dbeta(x, 7, 2), add=TRUE)

### Log-Normal Distribution
x <- rlnorm(n, 0, 1)
plot(x, main='random draws from a log-Normal distribution')
hist(x, probability=TRUE)
curve(dlnorm(x,0,1), add=TRUE)

### Exponential Distribution
x<-rexp(n, 0.1)
plot(x, main='random draws from an exponential distribution')
hist(x, probability=TRUE)
curve(dexp(x, 0.1), add=TRUE)

### Poisson Distribution
x<-rpois(n, 3)
plot(x, main='random draws from a Poisson distribution')
hist(x, probability = TRUE, breaks = seq(-0.5, max(x)+0.5, 1))
lines(0:10,dpois(0:10,3))

### Chi-squared Distribution
x<-rchisq(n, 3)
plot(x,main='random draws from a chi-squared distribution')
hist(x, probability=TRUE)
curve(dchisq(x,3), add=TRUE)

### Binomial Distribution
x<-rbinom(n, size=10,p=0.7)
plot(x, main='random draws from a binomial distribution')
hist(x, probability=TRUE, breaks = seq(-0.5,10.5))
lines(1:10, dbinom(1:10,size=10,p=0.7))
