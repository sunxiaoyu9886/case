# --- Simple Linear Regression ---
#1. Import data
data <- read.csv("brewdog.csv", header=TRUE)

#2. Plot data
plot(data$ABV, data$Price)
text(data$ABV, data$Price, labels=data$Name, cex=0.7, pos=2)

#3. Use linear regression
fit <- lm(Price ~ ABV, data=data)

#4. Add regression line
abline(fit)

#5. Extract coefficient
    coef(fit)
   #y=0.923x-2.77
     #slope   intercept

#6. Show regression output
summary(fit)							

#7. show fitted values for each data point
fitted(fit)

#8. show residuals for each data point
residuals(fit)

#9. Work out the centroid value (mean of both)
mean(data$ABV)
mean(data$Price)

# Plot centroid
points(mean(data$ABV), mean(data$Price), col = 'red')
plot(fit)

anova(fit)

# Histogram of residuals
hist(fit$residuals)					

