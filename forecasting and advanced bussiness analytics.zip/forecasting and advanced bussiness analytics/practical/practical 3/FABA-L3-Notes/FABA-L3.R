# Install packages
install.packages("forecast")
library("forecast")


# Import data
setwd("C:\\Users\\sunxi\\Desktop\\forecasting and advanced bussiness analytics\\practical\\FABA-L2-Notes")
data <- read.csv("iphonesales.csv", header=TRUE)
# save as time series data
ipts <- ts(data$Sales,start=c(2007, 3), end=c(2018, 4), frequency=4)

# BREAK OUT SESSION 1 ---------- Exponential Smoothing ----------

# Simple Exponential Smoothing - low alpha - less weight to recent observations
#if alpha is high,there is a high  reaction to differences
SES <- ses(ipts, alpha=0.1)			
plot(SES)

# Simple Exponential Smoothing - high alpha - more weight to recent observations
SES2 <- ses(ipts, alpha=0.9)			
plot(SES2)

# Simple Exponential Smoothing with alpha calculated for you
SES3 <- ses(ipts)					
summary(SES3)					
plot(SES3)

# Simple Exponential Smoothing using the ets function
se <- ets(ipts, model="ANN")			
plot(forecast(se))

# Multiplicative Holt-Winters' method with multiplicative errors
se <- ets(ipts, model="MAM")	
plot(forecast(se))


# BREAK OUT SESSION 2 ---------- ARIMA ----------

# ACF and PACF plots
tsdisplay(ipts)								
# first differenced plots
tsdisplay(diff(ipts))							
# second differenced plots
tsdisplay(diff(diff(ipts)))							

# ARIMA (0,1,0)
arm <- arima(ipts,order=c(0,1,0))					
plot(forecast(arm))
tsdisplay(residuals(arm))

# ARIMA (2,1,0)
arm <- arima(ipts,order=c(2,1,0))					
plot(forecast(arm))
tsdisplay(residuals(arm))

# Autofit ARIMA inc seasonal
afit <- auto.arima(ipts)							
# Plot 1yr ARIMA forecast
plot(forecast(afit,h=4))							
# Plot 2yr ARIMA forecast
plot(forecast(afit,h=8))							
# Plot 3yr ARIMA forecast
plot(forecast(afit,h=12))							
afit									
# ACF and PACF plots
tsdisplay(residuals(afit))							


# BREAK OUT SESSION 3 ---------- Forecast Accuracy ----------

# Let's use ES with 1:43 observations to predict 44:46 observations
fit1 <- ets(ipts[1:43], model="ZZZ")
plot(forecast(fit1, h=3))
lines(ipts[1:46])
# Let's now check the accuracy of ES: 
accuracy(forecast(fit1), ipts[44:46])
# Now we can compare this forecast with ARIMA:
fit2 <- auto.arima(ipts[1:43])
plot(forecast(fit2, h=3))
accuracy(forecast(fit2), ipts[44:46])
# Closer to 0 for each measure is best - which method is better?