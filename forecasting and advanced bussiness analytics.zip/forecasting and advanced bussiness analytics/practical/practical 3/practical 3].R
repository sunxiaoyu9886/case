#
setwd("C:\\Users\\sunxi\\Desktop\\forecasting and advanced bussiness analytics\\practical\\practial 3 data")

#import data��1��4��
psd <- read.csv("propertysales.csv", header=TRUE)
psts <- ts(psd$Sales,start=c(1995, 1), end=c(2019, 12), frequency=12)
pstrain <- window(psts, start=c(1995, 1), end=c(2019, 8))
pstest <- window(psts, start=c(2019, 9), end=c(2019, 12))


mgd <- read.csv("MGVisits.csv", header = TRUE, colClasses = c("character", "character"))
mgd$MGVisits<-as.numeric(gsub(",","",mgd$MGVisits))

mgts<-ts(mgd$MGVisits,start = c(2008,4),end=c(2019,4),frequency = 12)
mgtrain<-window(mgts,start=c(2018,4),end=c(2019,4))
mgtest<-window(mgts,start=c(2008,5),end=c(2019,9))


ed <- read.csv("emissions.csv", header=TRUE)
ets <- ts(ed$emissions,start=c(1959, 1), end=c(2014, 1), frequency=1)
etrain <- window(ets, start=c(1959, 1), end=c(2010, 1))
etest <- window(ets, start=c(2011, 1), end=c(2014, 1))

pd <- read.csv("prius.csv", header=TRUE)
pts <- ts(pd$Num,start=c(2008, 3), end=c(2015, 3), frequency=4)
ptrain <- window(pts, start=c(2008, 3), end=c(2014, 3))
ptest <- window(pts, start=c(2014, 4), end=c(2015, 3))


#1.decompose
de1<-decompose(pstrain,type = "additive")
plot(de1)
de2<-decompose(mgtrain,type = "multiplicative")
plot(de2)
de3<-decompose(ptrain ,type = "multiplicative")
plot(de3)
de4<-decompose(etrain,type = "multiplicative")
plot(de4)

#2.forecasting
install.packages("forecast")
library(forecast)

ps1<-meanf(pstrain,h=4)
plot(ps1)
ps2<-naive(pstrain,h=4)
lines(ps2$mean,col=2)
ps3<-snaive(pstrain,h=4)
lines(ps3$mean,col=3)
ps4<-rwf(pstrain,drift=TRUE,h=4)
lines(ps4$mean,col=4)

#3.exponential smoothing 
se1 <- ets(pstrain, model="ANN")			
plot(forecast(se1))
se2 <- ets(pstrain, model="AAN")			
plot(forecast(se2))
se3 <- ets(pstrain, model="AAA")			
plot(forecast(se3))
se4 <- ets(pstrain, model="MAM")			
plot(forecast(se4))


#4.arima
tsdisplay(pstrain)
tsdisplay(diff(pstrain))
tsdisplay((diff(diff(pstrain))))
# ARIMA (0,1,0)
arm <- arima(pstrain,order=c(0,1,0))					
plot(forecast(arm))
tsdisplay(residuals(arm))

# ARIMA (2,1,0)
arm <- arima(pstrain,order=c(2,1,0))					
plot(forecast(arm))
tsdisplay(residuals(arm))

# Autofit ARIMA inc seasonal
afit <- auto.arima(pstrain)							
# Plot 1yr ARIMA forecast
plot(forecast(afit,h=4))							
# Plot 2yr ARIMA forecast
plot(forecast(afit,h=8))							
# Plot 3yr ARIMA forecast
plot(forecast(afit,h=12))							
afit									
# ACF and PACF plots
tsdisplay(residuals(afit))							

#5. Forestcasting accuracy 
# Let's use ES with 1:43 observations to predict 44:46 observations
fit1 <- ets(pstrain, model="AAA")   #better
fit1 <- ets(pstrain, model="MAM")
plot(forecast(fit1, h=5))
lines(pstest)
# Let's now check the accuracy of ES: 
accuracy(forecast(fit1), pstest)
# Now we can compare this forecast with ARIMA:
fit2 <- auto.arima(pstrain)
plot(forecast(fit2, h=5))
accuracy(forecast(fit2), pstest)
# Closer to 0 for each measure is best - which method is better?