data<-state.x77
head(data)
summary(data)
cor(data[,c("Murder","Population","Illiteracy","Income","Frost")])
install.packages("corrgram")
library("corrgram")
corrgram(data[,c("Murder","Population","Illiteracy","Income","Frost")])
pairs(data[,c("Murder","Population","Illiteracy","Income","Frost")])
fit<-lm(Murder~Population+Illiteracy+Income+Frost,data=as.data.frame(data))
summary(fit)
fit2<-lm(Murder~Population+Illiteracy,data=as.data.frame(data))
summary(fit2)
anova(fit,fit2)

predict(fit2,list(Population=10000,Illiteracy=1.1))


#stepwise regression
fit3<-lm(Murder~.,data=as.data.frame(data))
fit4<-step(fit3,direction = "backward")


#logistic regression
data <- read.csv("http://www.hodgett.co.uk/titanic.csv", header=TRUE)
head(data)
nrow(data[which(is.na(data$age)),])
#impute
data$age[is.na(data$age)]<-mean(data$age,na.rm=TRUE)
nrow(data)
row_number<-sort(sample(nrow(data),nrow(data)*0.7))
train<-data[row_number,]
test<-data[-row_number,]
lfit<-glm(survived~sex+age+fare,family = binomial,data=train)
summary(lfit)
#assess
test2<-subset(test,select = c(4,5,9))
head(test2)
results<-predict(lfit,newdata = test2,type='response')
results<-ifelse(results>0.5,1,0)
mean(results==test$survived)


#confusion matrix
install.packages("caret")
library("caret")
confusionMatrix(as.factor(results),as.factor(test$survived))
